from django.shortcuts import render
from assign.model import UserDetail
from django.contrib import messages


def IndexPage(request):
    return render(request,'index.html')


def UserReg(request):
    if request.method=='POST':

        UserName=request.POST['UserName']
        Email=request.POST['Email']
        contact=request.POST['contact']
        password=request.POST['password']
        re_password=request.POST['re_password']
        UserDetail(UserName=UserName,Email=Email,contact=contact,password=password,re_password=re_password).save()
        messages.success(request,'the new user  '+request.POST['UserName']+" successfully registered!")
        return render(request,'Registration.html')
    else:
        return render(request,'Registration.html')

def LoginPage(request):
    if request.method=='POST':
        try:
            user=UserDetail.objects.get(Email=request.POST['Email'],password=request.POST['password'])
            print('userName',user)
            request.session['Email']=user.Email
            #request.session['password']=UserDetail.password
            return render(request,'index.html')
        except UserDetail.DoesNotExist as e:
            messages.success(request,"contact/password Invalied....")
    return render(request,'login.html')


def LogoutPage(request):
    try:
        del request.session['Email']
    except:
        return render(request,'index.html')
    return render(request,'index.html')

