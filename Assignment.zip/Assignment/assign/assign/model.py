from django.db import models

class UserDetail(models.Model):
    UserName=models.CharField(max_length=200,null=True)
    Email=models.CharField(max_length=200,null=True,unique=True)
    contact=models.CharField(max_length=10,null=False, blank=False, unique=True)
    password=models.CharField(max_length=12,null=True,unique=True)
    re_password=models.CharField(max_length=12,null=True)